package com.oops.abs;

public class Manager extends Employee{
	 String activity; 
	 
	public Manager(String empName, double salary, int empId, String activity) {
		super(empName, salary, empId);
		this.activity = activity;
	}

	// should have a parameterised constructor 
	 // override all three methods 
	
	 void funClub(){ 
	   System.out.println("Activity "+activity); 
	 }

	@Override
	void calcBonus(double amount) {
		System.out.println("Bonus:" +amount+500);
	}

	@Override
	String[] showCourses() {
		return null;
	}

	@Override
	void showProjects() {
		
	}
}