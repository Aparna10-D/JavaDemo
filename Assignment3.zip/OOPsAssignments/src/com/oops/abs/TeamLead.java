package com.oops.abs;

public class TeamLead extends Employee{

	public TeamLead(String empName, double salary, int empId) {
		super(empName, salary, empId);
		// TODO Auto-generated constructor stub
	}

	@Override
	void calcBonus(double amount) {
		// TODO Auto-generated method stub
		System.out.println(amount);
		
	}

	@Override
	String[] showCourses() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	void showProjects() {
		// TODO Auto-generated method stub
		
	}
	
	

}
