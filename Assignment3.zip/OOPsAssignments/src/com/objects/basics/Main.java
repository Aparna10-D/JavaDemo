package com.objects.basics;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Book book = new Book("The Alchemist", "Paulo Coelho", "Fiction", 350);
		book.getDetails();
		book.checkBookType();


	}

}
